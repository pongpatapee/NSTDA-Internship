from tkinter import *
from homeWindow import *

root = Tk() 
home_page = HomeWindow(root)
root.mainloop()